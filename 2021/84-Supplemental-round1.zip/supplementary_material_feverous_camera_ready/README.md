For clarification: Throughout the annotation process, we referred to the 'claim verification' phase in the paper as 'evidence annotation' when creating the dataset.
