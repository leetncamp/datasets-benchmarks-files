This is an example to show how to make your own task.
It's RACE task, to get start you need to download data from http://www.cs.cmu.edu/~glai1/data/race/

