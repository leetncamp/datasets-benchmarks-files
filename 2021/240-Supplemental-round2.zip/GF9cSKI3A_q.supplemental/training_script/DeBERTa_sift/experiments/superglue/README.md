# Dev performance on SuperGLUE

|Models    | COPA   | RTE     | ReCoRD(F1/EM)|
|----------|--------|---------|--------------|
|XXLarge-v2|97      |93.5     |94.1/93.7     | 
|XLarge-v2 |97      |93.5     |93.8/93.8     | 

