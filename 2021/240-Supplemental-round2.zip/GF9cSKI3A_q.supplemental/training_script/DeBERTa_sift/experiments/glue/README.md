# GLUE fine-tuning task
To run the experiment, you need to

run `./mnli.sh` for fine-tuning mnli base model, 

run `./mnli.sh` for fine-tuning mnli large model.

run `./cola.sh` for fine-tuning cola large model.

run `./sst2.sh` for fine-tuning sst2 large model.

run `./stsb.sh` for fine-tuning stsb large model.

run `./rte.sh` for fine-tuning rte large model.

run `./qqp.sh` for fine-tuning qqp large model.

run `./qnli.sh` for fine-tuning qnli large model.

run `./mrpc.sh` for fine-tuning mrpc large model.
