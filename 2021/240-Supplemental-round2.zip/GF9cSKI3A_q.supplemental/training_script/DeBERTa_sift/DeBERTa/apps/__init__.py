import os
# This statement must be executed at the very beginning, i.e. before import torch
os.environ["OMP_NUM_THREADS"] = "1"
