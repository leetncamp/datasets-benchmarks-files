# PASS: training and evaluation codes

This folder contains code to reproduce the results in the paper `PASS: An ImageNet replacement forself-supervised pretraining without humans`.

The folder is structured into three parts: `experts`, which are used for filtering the dataset before its creation, `pretraining`, which contains code for pretraining SSL methods and `evaluation` which contains further evaluation scripts.
Note also that we follow to a large degree the evaluations provided in MoCo and so some evaluations can be found in `pretraining/MoCo-v2` too.

## Usage
For every pretraining method, follow its own README and installation instructions.


 
