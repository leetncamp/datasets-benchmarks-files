#!/bin/bash
#SBATCH --job-name=adiwol
#SBATCH --time=3-00:00:00
#SBATCH --mem=16G
#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
##SBATCH --constraint=gmem12G
#SBATCH --cpus-per-task=8
#SBATCH --nodelist=gnodeb1,gnodei1,gnodee5,gnodee6
#SBATCH --mail-user=chrisr@robots.ox.ac.uk
#SBATCH --mail-type=START,END,FAIL,ARRAY_TASKS
pwd; hostname; date
source ~/.bashrc
date +"%R activating conda env"
source activate tf
date +"%R starting script"
cd ~/projects/adiwol/analysis || exit
module load cudnn/v8.11.1
python open_images.py

date +"%R slurm job done"
