


mkdir /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/knn
CUDA_VISIBLE_DEVICES=0 python -m torch.distributed.launch --nproc_per_node=1 eval_knn.py \
                         --data_path '/scratch/shared/beegfs/yuki/data/ILSVRC12' \
                         --arch deit_small \
                         --pretrained_weights /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/checkpoint.pth


PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
DATADIR='/scratch/local/ssd/datasets/Imagenet/'
mkdir '/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP'
CUDA_VISIBLE_DEVICES=0 ${PYTHON} -m torch.distributed.launch --nproc_per_node=1 eval_linear.py --data_path ${DATADIR} \
                         --arch deit_small --batch_size_per_gpu 256 \
                         --pretrained_weights /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/checkpoint.pth \
                         --output_dir /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP



PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
DATADIR='/scratch/local/ssd/datasets/Places/'
mkdir '/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP_places'
CUDA_VISIBLE_DEVICES=0 ${PYTHON} -m torch.distributed.launch --nproc_per_node=1 eval_linear.py --data_path ${DATADIR} \
                         --arch deit_small --batch_size_per_gpu 256 \
                         --pretrained_weights /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/checkpoint.pth \
                         --output_dir /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP_places



PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
DATADIR='/scratch/local/ssd/yuki/102flowers'
EXPDIR='/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP_flowers'
mkdir ${EXPDIR}
CUDA_VISIBLE_DEVICES=0 ${PYTHON} -m torch.distributed.launch --nproc_per_node=1 eval_linear.py --data_path ${DATADIR} \
                         --arch deit_small --batch_size_per_gpu 256 --num_labels 102 --dataset flowers \
                         --pretrained_weights /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/checkpoint.pth \
                         --output_dir ${EXPDIR}  2>&1 | tee -a ${EXPDIR}/log_lp_flowers.txt



PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
DATADIR='/scratch/shared/beegfs/yuki/data/herbarium2019'
EXPDIR='/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/LP_herba'
mkdir ${EXPDIR}
CUDA_VISIBLE_DEVICES=0 ${PYTHON} -m torch.distributed.launch --nproc_per_node=1 eval_linear.py --data_path ${DATADIR} \
                         --arch deit_small --batch_size_per_gpu 256 --num_labels 683 --dataset herba19 \
                         --pretrained_weights /scratch/shared/beegfs/yuki/adiwol/experiments/yuki/dino/checkpoint.pth \
                         --output_dir ${EXPDIR}  2>&1 | tee -a ${EXPDIR}/log_lp_herba19.txt