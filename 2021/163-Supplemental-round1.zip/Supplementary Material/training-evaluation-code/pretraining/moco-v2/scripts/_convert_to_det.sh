#!/bin/bash

EXP_STR=$1
EXPERIMENT_PATH="/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/${EXP_STR}"
CKPT=${EXPERIMENT_PATH}/checkpoints/checkpoint.pth.tar
if test -f "$CKPT"; then
    echo "using $CKPT ."
else
  CKPT=${EXPERIMENT_PATH}/checkpoint.pth.tar
  echo "using $CKPT "
fi

cd detection
python convert-pretrain-to-detectron2.py ${CKPT} ${EXPERIMENT_PATH}/converted.pkl
cd ../