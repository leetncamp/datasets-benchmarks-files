#!/bin/bash

EXP_STR="supervisedIN1k"

echo "launching LP on ILSVRC-12"
sbatch scripts/_eval_lin_cls.sh ${EXP_STR}

echo "launching LP on Places"
sbatch scripts/_eval_lin_cls_places.sh ${EXP_STR}
