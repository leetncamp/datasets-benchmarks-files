#!/bin/bash

EXP_STR='supervisedIN1k'

bash scripts/_convert_to_det.sh ${EXP_STR}
echo "converted file!"

echo "launching COCO"
sbatch scripts/_launch_det_fpn.sh ${EXP_STR}

echo "launching COCO densepose"
sbatch scripts/_launch_det_fpn_densepose.sh ${EXP_STR}

echo "launching COCO keypoint"
sbatch scripts/_launch_kp.sh ${EXP_STR}

echo "launching PVOC"
sbatch scripts/_launch_det_PVOC.sh ${EXP_STR}
