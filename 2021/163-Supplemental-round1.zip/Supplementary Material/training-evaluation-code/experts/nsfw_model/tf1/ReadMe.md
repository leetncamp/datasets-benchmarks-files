# Deprecated Tensorflow 1.x Version

This version of the nsfw_model training and validation code depends on Tensorflow 1.x and is deprecated.