# Evaluation

In this folder we provide further evaluation codes that go beyond the standard evaluations that are setup in the MoCo-v2 repo.
Namely:

`cluster_eval.py`: Computes the cluster evaluation

`eval_svm.py`: Does the low-shot SVM-based classification

The evaluations in the MoCo-v2 repo include all detection and segmentation experiments in the paper.