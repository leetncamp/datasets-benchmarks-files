PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
EXP_STR="byol"
EXPERIMENT_PATH="/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/${EXP_STR}"
MODEL="${EXPERIMENT_PATH}/checkpoint.pth.tar"
DEV=0

CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a resnet50 \
    --dataset 'voc2007' \
    --low-shot  \
    '/datasets/PascalVOC2007/' 2>&1 | tee -a ${EXPERIMENT_PATH}/voc_lowshot_hyper.txt
echo $MODEL


CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a resnet50 \
    --dataset 'places205' \
    --low-shot  \
    '/scratch/shared/beegfs/yuki/data/Places' 2>&1 | tee -a ${EXPERIMENT_PATH}/places_lowshot.txt
echo $MODEL


CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a resnet50 \
    --dataset 'herba19' \
    --low-shot  \
    '/scratch/shared/beegfs/yuki/data/herbarium2019' 2>&1 | tee -a ${EXPERIMENT_PATH}/herba19_lowshot.txt



PYTHON='/scratch/shared/beegfs/yuki/envs/py37/bin/python3'
EXP_STR="dino"
EXPERIMENT_PATH="/scratch/shared/beegfs/yuki/adiwol/experiments/yuki/${EXP_STR}"
MODEL="${EXPERIMENT_PATH}/checkpoint.pth.tar"
DEV=0

CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a deit_small \
    --dataset 'voc2007' \
    --low-shot  \
    '/datasets/PascalVOC2007/' 2>&1 | tee -a ${EXPERIMENT_PATH}/voc_lowshot_hyper.txt
echo $MODEL


CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a deit_small \
    --dataset 'places205' \
    --low-shot  \
    '/scratch/shared/beegfs/yuki/data/Places' 2>&1 | tee -a ${EXPERIMENT_PATH}/places_lowshot.txt
echo $MODEL


CUDA_VISIBLE_DEVICES=$DEV ${PYTHON} eval_svm.py --pretrained ${MODEL} \
    -a deit_small \
    --dataset 'herba19' \
    --low-shot  \
    '/scratch/shared/beegfs/yuki/data/herbarium2019' 2>&1 | tee -a ${EXPERIMENT_PATH}/herba19_lowshot.txt
echo $MODEL